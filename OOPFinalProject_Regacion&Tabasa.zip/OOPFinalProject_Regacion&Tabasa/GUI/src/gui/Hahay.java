package gui;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;



public class Hahay extends JFrame implements MouseListener {

	private static final long serialVersionUID = 1L;
	public static CardLayout card = new CardLayout();
	public static JPanel container = new JPanel();
	public static JPanel homePage = new JPanel();
	public static JPanel adminPage = new JPanel();
	public static JPanel adminLoggedIn = new JPanel();
	public static JPanel signUpPage = new JPanel();
	public static JPanel signUpTrue = new JPanel();
	public static JPanel continueAsUser = new JPanel();
	public static JPanel toAddProfile = new JPanel();
	public static JPanel toSearch = new JPanel();
	public static JPanel display = new JPanel();
	public static JPanel accounts = new JPanel();
	public static JPanel toFillInfo = new JPanel();
	public static JPanel msgBeforeSaving = new JPanel();
	
	public static JButton AdminButton;
	public static JButton ContinueAsUserButton;
	public static JButton LogInButton;
	public static JButton SignUpButton;
	public static JButton BackBtnAdminPage;
	public static JButton ApproveButton;
	public static JButton DeleteButton;
	public static JButton BackBtnAdminLoggedIn;
	public static JButton okButtonOK;
	public static JButton BackBtnSignUpPage;
	public static JButton ContinueButton;
	public static JButton BackButtonUser;
	public static JButton SearchButton;
	public static JButton CancelBtnDisplay;
	public static JButton AddProfileButton;
	public static JButton proceedButton;
	public static JButton payButton;
	public static JButton BackButtonAddProfile;
	public static JButton CAS;
	public static JButton CED;
	public static JButton CE;
	public static JButton CGB;
	public static JButton CT;
	public static JButton SAEC;
	public static JButton IC;
	public static JButton BackBtnToSearch;
	public static JButton SearchBtn;
	public static JButton CancelBtnAccounts;
	public static JButton CancelButtonFillInfo;
	public static JButton SaveButton;
	public static JButton OkButton;
	
	public static JTextField userNameField;
	public static JTextField passWordField;
	public static JTextField codeField;
	public static JTextField idNumberField;
	public static JTextField nameField;
	public static JTextField birthdateField;
	public static JTextField yrCourseField;
	public static JTextField yrEntryField;
	public static JTextField fathersNameField;
	public static JTextField mothersNameField;
	public static JTextField contactNumberField;
	public static JTextField idSearchField;
	public static JTextField amountField;
	
	private final String systemCode = "123usep";
	
	private static JTextArea textList;
	private static JTextArea textDisplay;
	private static JTextArea textAccounts;
	private static JTextArea txtInputAmount;
	

	File dir = new File ("AForApproval");
    File[] list = dir.listFiles(); 
    int fileCount = 1;
    final String[] num = new String[fileCount];
   // ang num kay ang sudlanan sa file.getName();
	int loop = 0; 
	
	final JList<String> lists = new JList<String>();
	private int balance = 6000 ;
	String strAmount = "";
	int finalAmount = 0;
	int amount = 0;
	
	
	public Hahay(){
		
		container.setLayout(card);
		homePage.setLayout(null);
		adminPage.setLayout(null);
		adminLoggedIn.setLayout(null);
		signUpPage.setLayout(null);
		signUpTrue.setLayout(null);
		continueAsUser.setLayout(null);
		toAddProfile.setLayout(null);
		toSearch.setLayout(null);
		toFillInfo.setLayout(null);
		msgBeforeSaving.setLayout(null);
		display.setLayout(null);
		accounts.setLayout(null);
		
		//for frame
		setSize(559, 480);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		
		//for Home Page - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		homePage.setBackground(Color.white);
		
		AdminButton = new JButton(new ImageIcon(gui.class.getResource("/gui/ADMINbutton.jpg")));
		AdminButton.setBounds(444, 11, 99, 29);
		AdminButton.addMouseListener(this);
		homePage.add(AdminButton);
		
		JLabel WelcomeText = new JLabel("");
		WelcomeText.setIcon(new ImageIcon(gui.class.getResource("/gui/WELCOME TEXT.jpg")));
		WelcomeText.setBounds(75, 72, 386, 63);
		homePage.add(WelcomeText);
		
		JLabel logo = new JLabel("");
		logo.setIcon(new ImageIcon(gui.class.getResource("/gui/LOGO.jpg")));
		logo.setBounds(157, 146, 212, 198);
		homePage.add(logo);
		
		ContinueAsUserButton = new JButton(new ImageIcon(gui.class.getResource("/gui/CONTINUEasUser.jpg")));
		ContinueAsUserButton.setBounds(163, 355, 223, 34);
		ContinueAsUserButton.addMouseListener(this);
		homePage.add(ContinueAsUserButton);
		
		//for Admin Page (katung naay log in ug sign up)- - - - - - - - - - - - - - - - 
		adminPage.setBackground(Color.white);
		
		JLabel AdminHeader1 = new JLabel(new ImageIcon(gui.class.getResource("/gui/adminHEADER.jpg")));
		AdminHeader1.setBounds(87, 0, 466, 57);
		adminPage.add(AdminHeader1);
		
		JTextArea txtUsername = new JTextArea();
		txtUsername.setEditable(false);
		txtUsername.setForeground(new Color(128, 0, 0));
		txtUsername.setFont(new Font("Arial", Font.BOLD, 20));
		txtUsername.setBackground(new Color(255, 255, 255));
		txtUsername.setText("   USERNAME:");
		txtUsername.setBounds(87, 239, 140, 28);
		adminPage.add(txtUsername);
		
		JTextArea txtPassword = new JTextArea();
		txtPassword.setForeground(new Color(128, 0, 0));
		txtPassword.setFont(new Font("Arial", Font.BOLD, 20));
		txtPassword.setBackground(new Color(255, 255, 255));
		txtPassword.setText("   PASSWORD:");
		txtPassword.setEditable(false);
		txtPassword.setBounds(87, 278, 140, 28);
		adminPage.add(txtPassword);
		
		userNameField = new JTextField();
		userNameField.setColumns(10);
		userNameField.setBackground(new Color(248, 248, 255));
		userNameField.setBounds(237, 239, 200, 28);
		userNameField.setText("");
		adminPage.add(userNameField);
		
		passWordField = new JTextField();
		passWordField.setBackground(new Color(248, 248, 255));
		passWordField.setBounds(237, 278, 200, 28);
		passWordField.setColumns(10);
		passWordField.setText("");
		adminPage.add(passWordField);
		
		JLabel icon = new JLabel("");
		icon.setIcon(new ImageIcon(gui.class.getResource("/gui/StudProfile.jpg")));
		icon.setBounds(216, 73, 144, 155);
		adminPage.add(icon);
		
		LogInButton = new JButton(new ImageIcon(gui.class.getResource("/gui/LOGinBUTTON.jpg")));
		LogInButton.setBounds(155, 353, 109, 35);
		LogInButton.addMouseListener(this);
		adminPage.add(LogInButton);
		
		SignUpButton = new JButton(new ImageIcon(gui.class.getResource("/gui/SIGNupButton.jpg")));
		SignUpButton.setBounds(309, 353, 109, 35);
		SignUpButton.addMouseListener(this);
		adminPage.add(SignUpButton);
		
		BackBtnAdminPage = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackBtnAdminPage.setForeground(Color.WHITE);
		BackBtnAdminPage.setBackground(Color.WHITE);
		BackBtnAdminPage.setBounds(0, 0, 44, 57);
		BackBtnAdminPage.addMouseListener(this);
		adminPage.add(BackBtnAdminPage);
		
		//for AdminLoggedIn - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		adminLoggedIn.setBackground(Color.white);
		
		JLabel AdminHeader2 = new JLabel(new ImageIcon(gui.class.getResource("/gui/adminHEADER.jpg")));
		AdminHeader2.setBounds(87, 0, 466, 57);
		adminLoggedIn.add(AdminHeader2);
		
		JLabel Icon = new JLabel(new ImageIcon(gui.class.getResource("/gui/PROFILEicon.jpg")));
		Icon.setBounds(225, 80, 102, 95);
		adminLoggedIn.add(Icon);
		
		textList = new JTextArea();
		textList.setBounds(150, 180, 250, 180);
		textList.setBackground(Color.WHITE);
		textList.setForeground(new Color(128, 0, 0));
		textList.setEditable(false);
		textList.setFont(new Font("Arial", Font.BOLD, 16));	
		// -------------------------------------------------------------------------------------------
        // Para pila ang sulod sa folder
		
		String[] lists = new String[2];
		
			for ( File file: list){
				
				int x = 0;
            	num[x] = file.getName();
            	lists[x] = num[x];
            	
            	textList.setText( lists[x] + "\n");
            	x++;
            	fileCount++;
       		
            	
			}
		
		/*
        
        if ( fileCount == 1){ 
        	
        	textList.setText("     No Profiles To Be Approved! "); 	
        	
        } else {
        	
        	//displaylistFiles(lists);
        	
        }*/
     
     // textList.setText( num[0] + " \n" );
        
     //textList.setText((num[0] + "\n" + num[1] + "\n" + num[2] + "\n" + num[3] + "\n" + " and " + (list.length - 4) + " others"));
        //	}
		adminLoggedIn.add(textList);
		
		ApproveButton = new JButton(new ImageIcon(gui.class.getResource("/gui/APPROVEbuton.jpg")));
		ApproveButton.setForeground(Color.WHITE);
		ApproveButton.setBackground(Color.WHITE);
		ApproveButton.setBounds(120, 380, 142, 42);
		ApproveButton.addMouseListener(this);
		adminLoggedIn.add(ApproveButton);
		
		DeleteButton = new JButton(new ImageIcon(gui.class.getResource("/gui/DELETEbutton.jpg")));
		DeleteButton.setBounds(300, 380, 142, 42);
		DeleteButton.addMouseListener(this);
		adminLoggedIn.add(DeleteButton);
		
		BackBtnAdminLoggedIn = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackBtnAdminLoggedIn.setBounds(0, 0, 45, 57);
		BackBtnAdminLoggedIn.addMouseListener(this);
		adminLoggedIn.add(BackBtnAdminLoggedIn);
		
		//for Sign Up Page (para sa mga gusto mag admin) - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		signUpPage.setBackground(Color.white);
		
		JLabel SignUpHeader = new JLabel(new ImageIcon(gui.class.getResource("/gui/SIGNupHEADER.jpg")));
		SignUpHeader.setBounds(87, 0, 466, 57);
		signUpPage.add(SignUpHeader);
		
		JTextArea txtEnterCode = new JTextArea();
		txtEnterCode.setFont(new Font("Arial", Font.BOLD, 30));
		txtEnterCode.setForeground(new Color(128, 0, 0));
		txtEnterCode.setBackground(Color.WHITE);
		txtEnterCode.setEditable(false);
		txtEnterCode.setText("ENTER CODE:");
		txtEnterCode.setBounds(167, 118, 218, 39);
		signUpPage.add(txtEnterCode);
		
		codeField = new JTextField("");
		codeField.setFont(new Font("Arial", Font.BOLD, 17));
		codeField.setBackground(new Color(245, 245, 245));
		codeField.setBounds(176, 168, 193, 43);
		codeField.setColumns(10);
		signUpPage.add(codeField);
		
		
		okButtonOK = new JButton(new ImageIcon(gui.class.getResource("/gui/OKbutton.jpg")));
		okButtonOK.setBounds(222, 231, 104, 33);
		okButtonOK.addMouseListener(this);
		signUpPage.add(okButtonOK);
		
		BackBtnSignUpPage = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackBtnSignUpPage.setBounds(0, 0, 45, 57);
		BackBtnSignUpPage.addMouseListener(this);
		signUpPage.add(BackBtnSignUpPage);
		
		//for Sign Up True (if tama ang code nga gienter) - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		signUpTrue.setBackground(Color.white);
		
		JTextArea txtYouAreNowAnAdmin = new JTextArea();
		txtYouAreNowAnAdmin.setForeground(new Color(128, 0, 0));
		txtYouAreNowAnAdmin.setBackground(Color.WHITE);
		txtYouAreNowAnAdmin.setEditable(false);
		txtYouAreNowAnAdmin.setFont(new Font("Arial", Font.BOLD, 35));
		txtYouAreNowAnAdmin.setText("You are now\r\n  an admin!");
		txtYouAreNowAnAdmin.setBounds(157, 123, 216, 96);
		signUpTrue.add(txtYouAreNowAnAdmin);
		
		ContinueButton = new JButton(new ImageIcon(gui.class.getResource("/gui/CONTINUEbutton.jpg")));
		ContinueButton.setBounds(166, 304, 202, 41);
		ContinueButton.addMouseListener(this);
		signUpTrue.add(ContinueButton);
		
		//for Continue As User- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		continueAsUser.setBackground(Color.white);
		
		BackButtonUser = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackButtonUser.setBounds(0, 0, 45, 57);
		BackButtonUser.addMouseListener(this);
		continueAsUser.add(BackButtonUser);
		
		SearchButton = new JButton("SEARCH");
		SearchButton.setBackground(new Color(128, 0, 0));
		SearchButton.setForeground(new Color(255, 255, 255));
		SearchButton.setFont(new Font("Arial", Font.BOLD, 18));
		SearchButton.setBounds(216, 182, 141, 48);
		SearchButton.addMouseListener(this);
		continueAsUser.add(SearchButton);
		
		AddProfileButton = new JButton("ADD PROFILE");
		AddProfileButton.setFont(new Font("Arial", Font.BOLD, 15));
		AddProfileButton.setForeground(new Color(255, 255, 255));
		AddProfileButton.setBackground(new Color(128, 0, 0));
		AddProfileButton.setBounds(216, 255, 141, 50);
		AddProfileButton.addMouseListener(this);
		continueAsUser.add(AddProfileButton);
		
		JLabel UserHeader = new JLabel(new ImageIcon(gui.class.getResource("/gui/userHeader.png")));
		UserHeader.setBounds(87, 0, 466, 57);
		continueAsUser.add(UserHeader);
		
		//for ToAddProfile - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		toAddProfile.setBackground(Color.white);
		
		JLabel USPheader = new JLabel(new ImageIcon(gui.class.getResource("/gui/uspHEADER.jpg")));
		USPheader.setBounds(87, 0, 500, 57);
		toAddProfile.add(USPheader);
		
		BackButtonAddProfile = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackButtonAddProfile.setBounds(0, 0, 45, 57);
		BackButtonAddProfile.addMouseListener(this);
		toAddProfile.add(BackButtonAddProfile);
		
		JTextArea txtFillOutYour = new JTextArea();
		txtFillOutYour.setForeground(new Color(128, 0, 0));
		txtFillOutYour.setEditable(false);
		txtFillOutYour.setFont(new Font("Arial", Font.BOLD, 16));
		txtFillOutYour.setText("Fill out your own information through your respective college");
		txtFillOutYour.setBounds(38, 85, 473, 34);
		toAddProfile.add(txtFillOutYour);
		
		JLabel CASlogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/cas.png")));
		CASlogo.setBounds(34, 138, 94, 102);
		toAddProfile.add(CASlogo);
		
		JLabel CEDlogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/educ-logo.jpg")));
		CEDlogo.setBounds(163, 138, 94, 102);
		toAddProfile.add(CEDlogo);
		
		JLabel CElogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/ce.png")));
		CElogo.setBounds(287, 138, 104, 102);
		toAddProfile.add(CElogo);
		
		JLabel CGBlogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/cgb.png")));
		CGBlogo.setBounds(414, 138, 104, 102);
		toAddProfile.add(CGBlogo);
		
		JLabel CTlogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/ct.png")));
		CTlogo.setBounds(94, 294, 104, 84);
		toAddProfile.add(CTlogo);
		
		JLabel SAEClogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/saec.png")));
		SAEClogo.setBounds(231, 294, 80, 89);
		toAddProfile.add(SAEClogo);
		
		JLabel IClogo = new JLabel(new ImageIcon(gui.class.getResource("/gui/ic.png")));
		IClogo.setBounds(351, 281, 104, 102);
		toAddProfile.add(IClogo);
		
		CAS = new JButton(new ImageIcon(gui.class.getResource("/gui/CAStext.jpg")));
		CAS.setBackground(new Color(255, 255, 255));
		CAS.setBounds(38, 245, 88, 29);
		CAS.addMouseListener(this);
		toAddProfile.add(CAS);
		
		CED = new JButton(new ImageIcon(gui.class.getResource("/gui/CEDtext.jpg")));
		CED.setBounds(173, 245, 72, 29);
		CED.addMouseListener(this);
		toAddProfile.add(CED);
		
		CE = new JButton(new ImageIcon(gui.class.getResource("/gui/CEtext.jpg")));
		CE.setBounds(297, 245, 80, 29);
		CE.addMouseListener(this);
		toAddProfile.add(CE);	
		
		CGB = new JButton(new ImageIcon(gui.class.getResource("/gui/CGBtext.jpg")));
		CGB.setBounds(414, 245, 104, 34);
		CGB.addMouseListener(this);
		toAddProfile.add(CGB);
		
		CT = new JButton(new ImageIcon(gui.class.getResource("/gui/CTtext.jpg")));
		CT.setBounds(107, 383, 72, 34);
		CT.addMouseListener(this);
		toAddProfile.add(CT);
		
		SAEC = new JButton(new ImageIcon(gui.class.getResource("/gui/SAECtext.jpg")));
		SAEC.setBounds(223, 383, 94, 28);
		SAEC.addMouseListener(this);
		toAddProfile.add(SAEC);
		
		IC = new JButton(new ImageIcon(gui.class.getResource("/gui/ICtext.jpg")));
		IC.setBounds(362, 388, 72, 29);
		IC.addMouseListener(this);
		toAddProfile.add(IC);
		
		//for ToSearch - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		toSearch.setBackground(Color.white);
		
		BackBtnToSearch = new JButton(new ImageIcon(gui.class.getResource("/gui/BACKbutton.jpg")));
		BackBtnToSearch.setForeground(Color.WHITE);
		BackBtnToSearch.setBackground(Color.WHITE);
		BackBtnToSearch.setEnabled(true);
		BackBtnToSearch.setBounds(0, 0, 45, 57);
		BackBtnToSearch.addMouseListener(this);
		toSearch.add(BackBtnToSearch);
		
		JLabel SearchEmptyHeader = new JLabel(new ImageIcon(gui.class.getResource("/gui/EmptyHEADER.jpg")));
		SearchEmptyHeader.setBounds(85, 0, 468, 57);
		toSearch.add(SearchEmptyHeader);
		
		JTextArea txtEnterIdNum = new JTextArea();
		txtEnterIdNum.setFont(new Font("Arial", Font.BOLD, 22));
		txtEnterIdNum.setForeground(new Color(128, 0, 0));
		txtEnterIdNum.setEditable(false);
		txtEnterIdNum.setText("ENTER ID NUMBER:");
		txtEnterIdNum.setBounds(169, 104, 217, 35);
		toSearch.add(txtEnterIdNum);
		
		idSearchField = new JTextField();
		idSearchField.setFont(new Font("Arial", Font.BOLD, 15));
		idSearchField.setBounds(154, 150, 244, 42);	
		idSearchField.setColumns(10);
		toSearch.add(idSearchField);
		
		SearchBtn = new JButton("SEARCH");
		SearchBtn.setForeground(new Color(255, 255, 255));
		SearchBtn.setBackground(new Color(128, 0, 0));
		SearchBtn.setBounds(216, 213, 114, 35);
		SearchBtn.addMouseListener(this);
		toSearch.add(SearchBtn);
		
		//Display  - - - - -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		display.setBackground(Color.WHITE);
		
		textDisplay = new JTextArea();
		textDisplay.setBounds(25, 70, 500, 300);
		textDisplay.setBackground(Color.WHITE);
		textDisplay.setForeground(new Color(128, 0, 0));
		textDisplay.setEditable(false);
		textDisplay.setFont(new Font("Arial", Font.BOLD, 15));
		display.add(textDisplay);
		
		JLabel EmptyHeaderDisplay = new JLabel(new ImageIcon(gui.class.getResource("/gui/EmptyHEADER.jpg")));
		EmptyHeaderDisplay.setBounds(-10, 0, 610, 57);
		display.add(EmptyHeaderDisplay);
		
		CancelBtnDisplay = new JButton("CANCEL");
		CancelBtnDisplay.setFont(new Font("Arial", Font.BOLD, 15));
		CancelBtnDisplay.setBackground(new Color(108, 0, 10));
		CancelBtnDisplay.setForeground(Color.WHITE);
		CancelBtnDisplay.setBounds(230, 409, 100, 32);
		CancelBtnDisplay.addMouseListener(this);
		display.add(CancelBtnDisplay);
		
		proceedButton = new JButton("Proceed To Accounts");
		proceedButton.setFont(new Font("Arial", Font.BOLD, 15));
		proceedButton.setBounds(350, 409, 190, 32);
		proceedButton.setForeground(Color.WHITE);
		proceedButton.setBackground(new Color(108, 0, 10));
		proceedButton.addMouseListener(this);
		display.add(proceedButton);		
		
		//FOR DISPLAYING ACCOUNTS  - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		accounts.setBackground(Color.WHITE);
		
		JLabel EmptyHeaderAccounts = new JLabel(new ImageIcon(gui.class.getResource("/gui/EmptyHEADER.jpg")));
		EmptyHeaderAccounts.setBounds(-10, 0, 610, 57);
		accounts.add(EmptyHeaderAccounts);
		
		JTextArea defaultAmount = new JTextArea();
		defaultAmount.setText("\nLATEST TRANSACTION\nTotal Amount Fees: P8000\nTotal Amount Paid: P2000\nRemaining Balance: P6000\n---------------------------------------");
		defaultAmount.setBounds(175, 50, 240, 130);
		defaultAmount.setFont(new Font("Arial", Font.BOLD, 18));
		defaultAmount.setEditable(false);
		defaultAmount.setForeground(new Color(128, 0, 0));
		defaultAmount.setBackground(Color.WHITE);		
		accounts.add(defaultAmount);
		
		textAccounts = new JTextArea();
		textAccounts.setBounds(165, 200, 250, 100);
		textAccounts.setBackground(Color.WHITE);
		textAccounts.setForeground(new Color(128, 0, 0));
		textAccounts.setEditable(false);
		textAccounts.setFont(new Font("Arial", Font.BOLD, 18));
		accounts.add(textAccounts);
		
		txtInputAmount = new JTextArea("Input amount: ");
		txtInputAmount.setBounds(230, 340, 120, 35);
		txtInputAmount.setForeground(new Color(128, 0, 0));
		txtInputAmount.setBackground(Color.WHITE);
		txtInputAmount.setEditable(false);
		txtInputAmount.setFont(new Font("Arial", Font.BOLD, 15));
		accounts.add(txtInputAmount);
		
		JTextArea pesoSign = new JTextArea("P");
		pesoSign.setBounds(178, 375, 20, 30);
		pesoSign.setForeground(new Color(128, 0, 0));
		pesoSign.setBackground(Color.WHITE);
		pesoSign.setEditable(false);
		pesoSign.setFont(new Font("Arial", Font.BOLD, 18));
		accounts.add(pesoSign);
		
		amountField = new JTextField();
		amountField.setBounds(190, 370, 180, 30);
		amountField.setColumns(10);
		amountField.setFont(new Font("Arial", Font.BOLD, 15));
		accounts.add(amountField);	
			
		CancelBtnAccounts = new JButton("CANCEL");
		CancelBtnAccounts.setFont(new Font("Arial", Font.BOLD, 15));
		CancelBtnAccounts.setBackground(new Color(108, 0, 10));
		CancelBtnAccounts.setForeground(Color.WHITE);
		CancelBtnAccounts.setBounds(170, 410, 100, 32);
		CancelBtnAccounts.addMouseListener(this);
		accounts.add(CancelBtnAccounts);
		
		payButton = new JButton("PAY");
		payButton.setFont(new Font("Arial", Font.BOLD, 15));
		payButton.setBounds(290, 410, 100, 32);
		payButton.setForeground(Color.WHITE);
		payButton.setBackground(new Color(108, 0, 10));
		payButton.addMouseListener(this);
		accounts.add(payButton);	
		//toFillInfo - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		toFillInfo.setBackground(Color.white);
		
		JTextArea txtFillOutYourInfo = new JTextArea();
		txtFillOutYourInfo.setForeground(Color.WHITE);
		txtFillOutYourInfo.setBackground(new Color(108, 0, 10));
		txtFillOutYourInfo.setEditable(false);
		txtFillOutYourInfo.setFont(new Font("Arial", Font.BOLD, 18));
		txtFillOutYourInfo.setText("Fill out your information:");
		txtFillOutYourInfo.setBounds(165, 20, 226, 26);
		toFillInfo.add(txtFillOutYourInfo);
		
		JLabel EmptyHeader = new JLabel(new ImageIcon(gui.class.getResource("/gui/EmptyHEADER.jpg")));
		EmptyHeader.setBounds(-10, 0, 610, 57);
		toFillInfo.add(EmptyHeader);
		
		JTextArea txtidNumber = new JTextArea();
		txtidNumber.setEditable(false);
		txtidNumber.setFont(new Font("Arial", Font.BOLD, 15));
		txtidNumber.setForeground(new Color(128, 0, 0));
		txtidNumber.setText("ID Number:");
		txtidNumber.setBounds(17, 109, 83, 26);
		toFillInfo.add(txtidNumber);
		
		idNumberField = new JTextField();
		idNumberField.setBounds(104, 108, 221, 26);
		idNumberField.setColumns(10);
		toFillInfo.add(idNumberField);
		
		JTextArea txtName = new JTextArea();
		txtName.setEditable(false);
		txtName.setForeground(new Color(128, 0, 0));
		txtName.setFont(new Font("Arial", Font.BOLD, 15));
		txtName.setText("Name:");
		txtName.setBounds(20, 146, 54, 22);
		toFillInfo.add(txtName);
		
		nameField = new JTextField();
		nameField.setBounds(74, 145, 251, 26);
		nameField.setColumns(10);
		toFillInfo.add(nameField);
				
		JTextArea txtBirthdate = new JTextArea();
		txtBirthdate.setEditable(false);
		txtBirthdate.setForeground(new Color(128, 0, 0));
		txtBirthdate.setFont(new Font("Arial", Font.BOLD, 15));
		txtBirthdate.setText("Birthdate:");
		txtBirthdate.setBounds(20, 182, 80, 22);
		toFillInfo.add(txtBirthdate);
		
		birthdateField = new JTextField();
		birthdateField.setBounds(104, 181, 221, 26);
		birthdateField.setColumns(10);
		toFillInfo.add(birthdateField);
				
		JTextArea txtYearcourse = new JTextArea();
		txtYearcourse.setEditable(false);
		txtYearcourse.setForeground(new Color(128, 0, 0));
		txtYearcourse.setFont(new Font("Arial", Font.BOLD, 15));
		txtYearcourse.setText("Year&Course:");
		txtYearcourse.setBounds(20, 218, 104, 26);
		toFillInfo.add(txtYearcourse);
		
		yrCourseField = new JTextField();
		yrCourseField.setBounds(128, 217, 197, 26);
		yrCourseField.setColumns(10);
		toFillInfo.add(yrCourseField);	
				
		JTextArea txtYearOfEntry = new JTextArea();
		txtYearOfEntry.setFont(new Font("Arial", Font.BOLD, 15));
		txtYearOfEntry.setEditable(false);
		txtYearOfEntry.setForeground(new Color(128, 0, 0));
		txtYearOfEntry.setText("Year of entry in USeP:");
		txtYearOfEntry.setBounds(20, 254, 160, 26);
		toFillInfo.add(txtYearOfEntry);
		
		yrEntryField = new JTextField();
		yrEntryField.setBounds(182, 253, 143, 26);
		yrEntryField.setColumns(10);
		toFillInfo.add(yrEntryField);
				
		JTextArea txtFathersName = new JTextArea();
		txtFathersName.setForeground(new Color(128, 0, 0));
		txtFathersName.setFont(new Font("Arial", Font.BOLD, 15));
		txtFathersName.setEditable(false);
		txtFathersName.setText("Father's Name:");
		txtFathersName.setBounds(20, 291, 110, 26);
		toFillInfo.add(txtFathersName);
		
		fathersNameField = new JTextField();
		fathersNameField.setBounds(135, 290, 190, 26);
		fathersNameField.setColumns(10);
		toFillInfo.add(fathersNameField);
			
		JTextArea txtMothersName = new JTextArea();
		txtMothersName.setFont(new Font("Arial", Font.BOLD, 15));
		txtMothersName.setEditable(false);
		txtMothersName.setForeground(new Color(128, 0, 0));
		txtMothersName.setText("Mother's Name:");
		txtMothersName.setBounds(20, 328, 115, 26);
		toFillInfo.add(txtMothersName);
		
		mothersNameField = new JTextField();
		mothersNameField.setBounds(135, 327, 190, 26);
		mothersNameField.setColumns(10);
		toFillInfo.add(mothersNameField);
				
		JTextArea txtContactNumber = new JTextArea();
		txtContactNumber.setFont(new Font("Arial", Font.BOLD, 15));
		txtContactNumber.setEditable(false);
		txtContactNumber.setForeground(new Color(128, 0, 0));
		txtContactNumber.setText("Contact Number in case of emergency:");
		txtContactNumber.setBounds(20, 360, 277, 22);
		toFillInfo.add(txtContactNumber);
		
		contactNumberField = new JTextField();
		contactNumberField.setBounds(135, 385, 190, 26);
		contactNumberField.setColumns(10);
		toFillInfo.add(contactNumberField);	
		
		CancelButtonFillInfo = new JButton(new ImageIcon(gui.class.getResource("/gui/CANCELbutton.png")));
		CancelButtonFillInfo.setBackground(Color.WHITE);
		CancelButtonFillInfo.setForeground(Color.WHITE);
		CancelButtonFillInfo.setBounds(360, 409, 83, 32);
		CancelButtonFillInfo.addMouseListener(this);
		toFillInfo.add(CancelButtonFillInfo);
		
		SaveButton = new JButton(new ImageIcon(gui.class.getResource("/gui/SAVEbutton.jpg")));
		SaveButton.setBounds(460, 409, 83, 32);
		SaveButton.addMouseListener(this);
		toFillInfo.add(SaveButton);
		
		//for Msg Before Saving - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
		msgBeforeSaving.setBackground(Color.white);
		
		JTextArea txtMessage = new JTextArea();
		txtMessage.setEditable(false);
		txtMessage.setFont(new Font("Arial", Font.BOLD, 25));
		txtMessage.setForeground(new Color(128, 0, 0));
		txtMessage.setText("      INFORMATION WILL\r\n           BE PUBLISHED\r\nAFTER ADMIN'S APPROVAL.");
		txtMessage.setBounds(110, 123, 359, 91);
		msgBeforeSaving.add(txtMessage);
		
		OkButton = new JButton(new ImageIcon(gui.class.getResource("/gui/OKbutton.jpg")));
		OkButton.setBounds(211, 265, 107, 40);
		OkButton.addMouseListener(this);
		msgBeforeSaving.add(OkButton);
		
		
	//adding panels to container
		container.add(homePage, "homePage");
		container.add(adminPage, "adminPage");
		container.add(adminLoggedIn, "adminLoggedIn");
		container.add(signUpPage, "signUpPage");
		container.add(signUpTrue, "signUpTrue");
		container.add(continueAsUser, "continueAsUser");
		container.add(toAddProfile, "toAddProfile");
		container.add(toSearch, "toSearch");
		container.add(display, "display");
		container.add(accounts, "accounts");
		container.add(toFillInfo, "toFillInfo");
		container.add(msgBeforeSaving, "msgBeforeSaving");
		
		card.show(container, "1");
	}
	

	public static void main(String[] args) {
		try {
		Hahay g = new Hahay();
		g.add(container);
		g.setVisible(true);
		} catch (Exception e){		
			e.printStackTrace();
			//JOptionPane.showMessageDialog(null,"                     Exception Occurs!","",JOptionPane.PLAIN_MESSAGE);       
		}
		
	}

	public void mouseClicked(MouseEvent me) {
		
		if(me.getSource() == AdminButton){
			card.show(container, "" + "adminPage");
		}
		
		if(me.getSource() == BackBtnAdminPage){
			card.show(container, "" + "homePage");
		}
		
		if(me.getSource() == LogInButton){
			String userName = userNameField.getText();
			String passWord = passWordField.getText();
			
		
				try {
					logIn(userName, passWord);
				} catch (IOException e) {
					System.out.print("");
				}
		}
		
		if(me.getSource() == ApproveButton){
			try {
				ApproveButton();
			} catch (IOException e) {
				System.out.println();
			}
		}
		
		if(me.getSource() == DeleteButton){
			try {
				DeleteButton();
			} catch (IOException e) {
				System.out.println();
			}
		}
		
		if(me.getSource() == BackBtnAdminLoggedIn){
			card.show(container, "" + "adminPage");
		}
		
		if(me.getSource() == SignUpButton){
			signUp();
		}
		
		if(me.getSource() == BackBtnSignUpPage){
			card.show(container, "" + "adminPage");
			userNameField.setText("");
	        passWordField.setText("");
		}
		
		if(me.getSource() == okButtonOK){
			try {
				okButton();
			} catch (IOException e) {
				System.out.print("");
			}
		}
		
		if(me.getSource() == ContinueButton){
			card.show(container, "" + "adminLoggedIn");
		}
		
		if(me.getSource() == ContinueAsUserButton){
			card.show(container, "" + "continueAsUser");
		}
		
		if(me.getSource() == BackButtonUser){
			card.show(container, "" + "homePage");
		}
		
		if(me.getSource() == SearchBtn){
			
			try {
				searchButton();
			} catch (IOException e) {
				System.out.println();
			}
		
		}
		
		if(me.getSource() == CancelBtnDisplay){
			card.show(container, "" + "toSearch");
			idSearchField.setText("");
		}
		
		if(me.getSource() == proceedButton){
			card.show(container, "" + "accounts");
			amountField.setText("");
		}
		
		if(me.getSource() == CancelBtnAccounts){
			card.show(container, "" + "display");
		}
		
		
	
		
		if(me.getSource() == payButton){
		   /*
			String search = idSearchField.getText();
			String strPayment = amountField.getText();
			int payment = Integer.parseInt(strPayment);
		
		try{
			textAccounts.setText("  Total Amount Fees: P" + 8000 + "\n  Total Amount Paid: P" + payment +  "\n  Remaining Balance: P" + balance + "\n  Change: P" + (payment - balance)*-1);
		    amountField.setText("");
            
              
                     if( payment <= 0){
                         
                    	   
						   JOptionPane.showMessageDialog(null,"                  You entered invalid amount!","",JOptionPane.PLAIN_MESSAGE);
						   amountField.setText(""); 
						    card.show(container, "" + "accounts");
                           balance = 2000;
                        
                    } else if ( payment < balance && payment < 500){
                            
                        if(balance>=500){
                        	balance = 2000;
                          JOptionPane.showMessageDialog(null,"You Input Below The Minimum Payment","",JOptionPane.PLAIN_MESSAGE);
  					      amountField.setText("");
  					      card.show(container, "" + "accounts");

                        
                        } else {
                            
                         if (payment!= balance){
                             
                        	 JOptionPane.showMessageDialog(null,"Transaction Failed.\n Please Pay The Remaining Balance!","",JOptionPane.PLAIN_MESSAGE);
     					      amountField.setText("");
     					      card.show(container, "" + "accounts");
                             
                        } else {
                                balance = 0;
                                System.out.println("Balance: "+balance);
                                System.out.println("School Credentials are already paid!");
                                System.out.println("Thank You For Visiting This Profile!\n");
                            }           
                        }
                    } else if (payment >= balance){
                        
                         this.balance = balance - payment;
           
                         System.out.println("Balance: P"+ balance);
                         System.out.println("Change: P" + (balance * -1));
                         System.out.println("School Credentials are already paid!");
                         System.out.println("Thank You For Visiting This Profile!\n");
                         System.out.println();
                         
                    } else {
                        
                        this.balance = balance - payment;
                        
                             if (balance == 0){
                            	  JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
                            }
                       
                    }
			} catch (Exception e){
				
				e.printStackTrace();
                    
    }
			
			
		*/	
			
			
	
			
			String search = idSearchField.getText();
			strAmount = amountField.getText();
			 amount = Integer.parseInt(strAmount);
			int fees = 8000;
			int amountPaid = amount + 2000;
			int balanceNow = fees - amountPaid;
			//String[] read = new String[20];
			//String bal = "";
		    
			try {
				 FileWriter fw = new FileWriter("D:\\OOP\\GUI\\AlreadyApproved\\" + search + ".txt", true);
			
				 
				 fw.write(balance);
				
				if (this.amount >= balance){
					 	  
					  textAccounts.setText("  Total Amount Fees: P" + fees + "\n  Total Amount Paid: P" + this.amount +  "\n  Remaining Balance: P" + (this.amount - balance)*-1 + "\n  Change: P" + (this.amount - balance)*-1);
				      amountField.setText("");
				     // balance =  (amount - balance)*-1;
				      String save = ("Remaining Balance: " + (this.amount - balance)*-1);
					  fw.append(save);
				      fw.close();
				      
				      JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
				      
				      if(balance==0){
				      textAccounts.setText("  Total Amount Fees: P" + fees + "\n  Total Amount Paid: P" + amount +  "\n  Remaining Balance: P0" + "\n  Change: P0");
				      JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
				      card.show(container, "" + "accounts");
				      }
				      
				 }else if ( amount <= 0){
						    
						   JOptionPane.showMessageDialog(null,"                  You entered invalid amount!","",JOptionPane.PLAIN_MESSAGE);
							amountField.setText(""); 
							card.show(container, "" + "accounts");
						 
			    } else if ( amount < 500){
			    	
					      JOptionPane.showMessageDialog(null,"You Input Below The Minimum Payment","",JOptionPane.PLAIN_MESSAGE);
					      amountField.setText("");
					      card.show(container, "" + "accounts");
						 
			  } else if ( this.amount >= 500 && this.amount < balance){
				 
				  balanceNow = balance - this.amount; 
				 // finalAmount = this.amount + amount;
				  finalAmount += amount;
				  
				  textAccounts.setText("  Total Amount Fees: P" + fees + "\n  Total Amount Paid: P" + (finalAmount+2000) +  "\n  Remaining Balance: P" + (balanceNow) );
			      amountField.setText("");
			      this.amount = finalAmount;
			      			      
			      this.balance = (balanceNow);
			      String save = ("Remaining Balance: " + balance);
				  fw.append(save);
			      fw.close();
			  }			 
			}catch (IOException e) {
				e.printStackTrace();
			}			 
		}		 
				 
					
				/*if(amount > balance){
					remainingBalance = 0;
					textAccounts.setText("  Total Amount Fees: P" + fees + "\n  Total Amount Paid: P" + paid +  "\n Remaining Balance: P" + remainingBalance+ "\n  Change: P" + change);
			        amountField.setText("");
			        //card.show(container, "" + "accounts");
			       
					fw.append("Remaining Balance:\n     " + remainingBalance + "\n");
					fw.close();
					
					JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
				} else if(amount >= 500 && amount <= remainingBalance){
								
					textAccounts.setText("  Total Amount Fees: P" + fees + "\n  Total Amount Paid: P" + paid + "\n  Remaining Balance: P" + remainingBalance);
			        amountField.setText("");
			        //card.show(container, "" + "accounts");
			       
					fw.append("Total amount fees: " + balance + "\n");
					fw.append("Entrance Fee: " + registration + "\n");
					fw.append("Remaining Balance: " + remainingBalance + "\n");
					fw.append("You input amount: " + amount + "\n");
					fw.append("Total amount paid: " + paid + "\n");
					fw.append("Current Balance: " + balanceNow + "\n\n");
													
					fw.close();
				}				
				
			} catch (IOException e) {
				System.out.println();
			}
			
			if( amount<0){    
				
				JOptionPane.showMessageDialog(null,"                  You entered invalid amount!","",JOptionPane.PLAIN_MESSAGE);
				amountField.setText(""); 
				card.show(container, "" + "accounts");
				
			} else if ( amount < balance && amount < 500){
			        
			    if(balance>=500){  
			    	if(amount < balance){
			    	amount = 0;
			    	JOptionPane.showMessageDialog(null,"You Input Below The Minimum Payment","",JOptionPane.PLAIN_MESSAGE);
			    	amountField.setText("");
			    	card.show(container, "" + "accounts");
			    	}
			    } else {
			        
			     if (amount!= balance){
			         
			    	 JOptionPane.showMessageDialog(null,"Transaction Failed.\n Please Pay The Remaining Balance!","",JOptionPane.PLAIN_MESSAGE); 
			    	 amountField.setText("");
			    	 card.show(container, "" + "accounts");
			    } else {	
			    	if(balance == 0){
			    		textAccounts.setText("  Total Amount Fees: P" + balance + "\n  Total Amount Paid: P" + (registration + amount) + "\n  Balance: P0" );
				        amountField.setText("");
			            JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
			    	}
			      }
			   
			    }
			} else {
			    balance = balanceNow;
			         if (balance == 0){
			        	 JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
			        }  
			}*/// } catch (IOException e) {
				//e.printStackTrace();
			//}
		
		
		if(me.getSource() == BackBtnToSearch){
			card.show(container, "" + "continueAsUser");
		}
		
		if(me.getSource() == SearchButton){
			card.show(container, "" + "toSearch");
		}
		
		if(me.getSource() == AddProfileButton){
			card.show(container, "" + "toAddProfile");
		}
		
		if(me.getSource() == BackButtonAddProfile){
			card.show(container, "" + "continueAsUser");
		}
		
		if(me.getSource() == CAS){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == CED){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == CE){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == CGB){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == CT){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == SAEC){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == IC){
			card.show(container, "" + "toFillInfo");
		}
		
		if(me.getSource() == CancelButtonFillInfo){
			card.show(container, "" + "toAddProfile");
		}
		
		if(me.getSource() == SaveButton){
			try {
				saveButton();
			} catch (IOException e) {
				System.out.print("");
			}
		}
		
		if(me.getSource() == OkButton){
			card.show(container, "" + "toAddProfile");
		}
		

		}

	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}


	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	//FUNCTION FOR LOG IN :) - - -- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	public void logIn(String userName, String passWord) throws IOException{
       
		java.io.File file = new java.io.File("D:\\OOP\\GUI\\Admin\\" + userName +".txt");
        
        try{
            @SuppressWarnings("resource")
			Scanner reader = new Scanner(file);
            
            while (reader.hasNext()){
            
            String num = reader.nextLine();
            
            if (num == null ? passWord == null : num.equals(passWord)){
                
            	card.show(container, "" + "adminLoggedIn");
                
            } else {
            	JOptionPane.showMessageDialog(null,"                     Password Incorrect!","",JOptionPane.PLAIN_MESSAGE);
            }
        } 
            
    } catch (FileNotFoundException e){
        
    	userNameField.setText("");
    	passWordField.setText("");
    	JOptionPane.showMessageDialog(null,"                     You are not an admin!","",JOptionPane.PLAIN_MESSAGE); 
    	card.show(container, "" + "adminPage");
    }
 
   }
	
	// PARA SA APPROVE BUTTON - - - - - - - - - -- -- - - - - - - - - - - - - - - - - - - - -- - - - - - - - - - - - - - - - - 
	public void ApproveButton() throws IOException{
    	
		 File dir = new File ("AForApproval");
         File[] list = dir.listFiles();
		
         for(File file : list){
        	
        	 FileWriter fw = new FileWriter("D:\\OOP\\GUI\\AlreadyApproved\\" + file.getName());
             PrintWriter pw = new PrintWriter(fw);
             
               @SuppressWarnings("resource")
			Scanner reader = new Scanner(file);
              while (reader.hasNext()){
         
              String num = reader.nextLine(); 
              pw.println(num); 
               }
              pw.close(); 
         	}
         JOptionPane.showMessageDialog(null,"                     All Files Approved!","",JOptionPane.PLAIN_MESSAGE);
         
	}  
	
	// DELETE BUTTON  - - -- - - - - -- - - - - - - - -- - - - - -- - - - -- - - - - - - - -- - - - - - - - - - - - - -
	public void DeleteButton() throws IOException{
		
			for (File file: list){
			file.delete();
			}
	JOptionPane.showMessageDialog(null,"                         All Files Deleted!","",JOptionPane.PLAIN_MESSAGE);
    	textList.setText("");	
    	
	}
	
	
	/*public void displaylistFiles(JList<String> list){
		DefaultListModel<String> model1 = new DefaultListModel<String>();
		
	    File listFiles = new File("D:\\OOP\\GUI\\AForApproval");
	    File[] yourFileList = listFiles.listFiles();
	    
	    for(File f : yourFileList) {
	        model1.addElement(f.getName());
	    }
	    list.setModel(model1);
	}*/
	
	// SIGN UP BUTTON  - - -- - - - - -- - - - - - - - -- - - - - -- - - - -- - - - - - - - -- - - - - - - - - - - - - -
	@SuppressWarnings("resource")
	public void signUp(){
		String userName = userNameField.getText();
		
		File file = new File("D:\\OOP\\GUI\\Admin\\" + userName +".txt");
        try{
            
            @SuppressWarnings("unused")
			Scanner reader = new Scanner(file);
            
            JOptionPane.showMessageDialog(null,"                Username already exist!","",JOptionPane.PLAIN_MESSAGE);
            userNameField.setText("");
        	passWordField.setText("");
        } catch (FileNotFoundException e){
        	userNameField.setText("");
         	passWordField.setText("");
        	card.show(container, "" + "signUpPage");
        }
		
	}
	
	//OK BUTTON.. Checks if tama ang code para makasign-up - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
	public void okButton() throws IOException{
		String userName = userNameField.getText();
		String passWord = passWordField.getText();
		String code = codeField.getText();
    
   if ( code.equals(systemCode)){
    	   FileWriter fw = new FileWriter("D:\\OOP\\GUI\\Admin\\" + userName + ".txt");
           PrintWriter pw = new PrintWriter(fw);
           pw.println(passWord);
           pw.close(); 
    	  JOptionPane.showMessageDialog(null,"                  You are now an admin!","",JOptionPane.PLAIN_MESSAGE);
    	  userNameField.setText("");
      	  passWordField.setText("");
      	  codeField.setText("");
    	  card.show(container, "" + "adminLoggedIn");
	    } else{
	    	codeField.setText("");
	    	JOptionPane.showMessageDialog(null,"       Code does not match system code!","",JOptionPane.PLAIN_MESSAGE);
	    }
}
	
	// SAVE BUTTON  - - -- - - - - -- - - - - - - - -- - - - - -- - - - -- - - - - - - - -- - - - - - - - - - - - - -	
	public void saveButton() throws IOException{
	
	String idNum = idNumberField.getText();
	String name = nameField.getText();
	String birthdate = birthdateField.getText();
	String yrCourse = yrCourseField.getText();
	String yrEntry = yrEntryField.getText();
	String fatherName = fathersNameField.getText();
	String motherName = mothersNameField.getText();
	String contactNumber = contactNumberField.getText();
 
        File file = new File("D:\\OOP\\GUI\\AForApproval\\" + idNum +".txt");
        idNumberField.setText("");
    	nameField.setText("");
    	birthdateField.setText("");
    	yrCourseField.setText("");
    	yrEntryField.setText("");
    	fathersNameField.setText("");
    	mothersNameField.setText("");
    	contactNumberField.setText("");
    	
        try{          
            @SuppressWarnings({"resource", "unused" })
			Scanner reader = new Scanner(file);
            
            JOptionPane.showMessageDialog(null,"      Identification number already exist!","",JOptionPane.PLAIN_MESSAGE);
           
        } catch (FileNotFoundException e){
  
	        if(idNum.isEmpty() || name.isEmpty() || birthdate.isEmpty() || yrCourse.isEmpty() || yrEntry.isEmpty() || fatherName.isEmpty() || motherName.isEmpty() || contactNumber.isEmpty() ){	        	
	        	JOptionPane.showMessageDialog(null,"      Provide All Needed Information!","",JOptionPane.PLAIN_MESSAGE);
	        	        } else {
	        FileWriter fw = new FileWriter("D:\\OOP\\GUI\\AForApproval\\" + idNum + ".txt");
	        PrintWriter pw = new PrintWriter(fw);
	        pw.println("ID Number: "+idNum);     
	        pw.println("Name: "+name);
	        pw.println("Birthdate: "+ birthdate);
	        pw.println("Year & Course: "+yrCourse); 
	        pw.println("Year Entry: "+yrEntry);
	        pw.println("Father's Name: "+fatherName);
	        pw.println("Mother's Name: "+motherName);
	        pw.println("Contact Number in Case Of Emergency:\n     " +contactNumber);
	        pw.close();
	        
	        JOptionPane.showMessageDialog(null,"Information will be published after admin's approval!","",JOptionPane.PLAIN_MESSAGE);
	        
	        idNumberField.setText("");
        	nameField.setText("");
        	birthdateField.setText("");
        	yrCourseField.setText("");
        	yrEntryField.setText("");
        	fathersNameField.setText("");
        	mothersNameField.setText("");
        	contactNumberField.setText("");
	        }
          }  
	}

	//SEARCH BUTTON AND  - - -- - - - - -- - - - - - - - -- - - - - -- - - - -- - - - - - - - -- - - - - - - - - - - - -
	public void searchButton() throws IOException{
		
	String[] num= new String[9];
	String search = idSearchField.getText();
    File file = new File("D:\\OOP\\GUI\\AlreadyApproved\\" + search  + ".txt");
    
    try{      
        @SuppressWarnings("resource")
		Scanner reader = new Scanner(file).useDelimiter("\n");
        card.show(container, "" + "display");
        
        	for(int x = 0; x<9; x++){
        		num[x] = reader.nextLine();
        	}
        	 textDisplay.setText((num[0] +"\n"+ num[1] + "\n"+ num[2] + "\n"+ num[3] + "\n"+ num[4]+ "\n"+ num[5] + "\n"+ num[6]+ "\n"+ num[7]+ "\n"+ num[8]));
        
        	
        //	 textDisplay.setText((num));
    } catch (FileNotFoundException e){        
    	JOptionPane.showMessageDialog(null,"                           File Not Found!","",JOptionPane.PLAIN_MESSAGE);
    	idSearchField.setText("");
    }	
}
	
	//PAY BUTTON.. SA ACCOUNTS NI - - -- - - - - -- - - - - - - - -- - - - - -- - - - -- - - - - - - - -- - - - - - - - - -	
	/*
	public void payButton() throws IOException{
		int balance = 8000;
		String search = idSearchField.getText();
		String strAmount = amountField.getText();
		int amount = Integer.parseInt(strAmount);
	
		//int paid = registration + amount;
		//int balanceNow = balance - paid;
		
		textAccounts.setText("  Total Amount Fees: P" + balance + "\n  Total Amount Paid: P" + (registration + amount) + "\n  Remaining Balance: P" + (balance -(registration + amount)));
        amountField.setText("");
        //card.show(container, "" + "accounts");
        
		//FileWriter fw = new FileWriter("D:\\OOP\\GUI\\AlreadyApproved\\" + search + ".txt", true);
		fw.append("Total amount fees: " + balance + "\n");
		fw.append("Entrance Fee: " + registration + "\n");
		fw.append("Remaining Balance: " + remainingBal + "\n");
		fw.append("You input amount: " + amount + "\n");
		fw.append("Total amount paid: " + paid + "\n");
		fw.append("Current Balance: " + balanceNow + "\n\n");
		
		registration = 2000;
		paid = registration + amount;
		balanceNow = (balance -(registration + amount));
		
        if( amount<0){    
        	
        	JOptionPane.showMessageDialog(null,"                  You entered invalid amount!","",JOptionPane.PLAIN_MESSAGE);
        	amountField.setText(""); 
        	card.show(container, "" + "accounts");
        	
        } else if ( amount < balance && amount < 500){
                
            if(balance>=500){  
            	if(amount < balance){
            		amount = 0;
            	JOptionPane.showMessageDialog(null,"You Input Below The Minimum Payment","",JOptionPane.PLAIN_MESSAGE);
            	//amountField.setText("");
            	card.show(container, "" + "accounts");
            	}
            } else {
                
             if (amount!= balance){
                 
            	 JOptionPane.showMessageDialog(null,"Transaction Failed.\n Please Pay The Remaining Balance!","",JOptionPane.PLAIN_MESSAGE); 
            	 //amountField.setText("");
            	 card.show(container, "" + "accounts");
            } else {
                    balance = 0;
                    System.out.println("Balance: "+balance);
                    JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
                }
             //card.show(container, "" + "accounts");
            // accounts();
            }
        } else if (amount >= balance){
             balance = balanceNow;
             System.out.println("Balance: P"+ balance);
             System.out.println("Change: P" + (balanceNow * -1));
             System.out.println("School Credentials are already paid!");
             System.out.println("Thank You For Visiting This Profile!\n");
             System.out.println();
             
        } else {
            balance = balanceNow;
                 if (balance == 0){
                	 JOptionPane.showMessageDialog(null,"School Credentials are already paid!\nThank You For Visiting This Profile!","",JOptionPane.PLAIN_MESSAGE); 
                }  
           // accounts();
        }

        fw.close();
	}
	*/

}
		



